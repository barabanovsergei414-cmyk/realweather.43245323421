package dev.meteo.pmtornado.client;

import dev.meteo.pmtornado.entity.TornadoEntity;
import dev.meteo.pmtornado.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

public final class TornadoWindSound extends AbstractTickableSoundInstance {
    private final TornadoEntity tornado;

    public TornadoWindSound(TornadoEntity tornado) {
        super(ModSounds.TORNADO_WIND.get(), SoundSource.WEATHER, RandomSource.create());
        this.tornado = tornado;
        this.looping = true;
        this.delay = 0;
        this.volume = 0.0F;
        this.pitch = 0.84F;
        this.relative = false;
        this.attenuation = SoundInstance.Attenuation.LINEAR;
    }

    @Override
    public void tick() {
        if (tornado.isRemoved() || Minecraft.getInstance().level != tornado.level()) {
            stop();
            ClientSoundEvents.soundStopped(tornado.getId());
            return;
        }
        this.x = tornado.getX();
        this.y = tornado.getY() + tornado.getMaxHeight() * 0.35;
        this.z = tornado.getZ();
        float growth = tornado.getGrowthProgress(0.0F);
        this.volume = Mth.clamp(0.12F + growth * tornado.getStrength() * 0.9F, 0.0F, 0.95F);
        this.pitch = 0.72F + tornado.getStrength() * 0.24F;
    }
}
