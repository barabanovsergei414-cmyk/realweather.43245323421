package dev.meteo.pmtornado.client;

import dev.meteo.pmtornado.PMWeatherTornadoAddon;
import dev.meteo.pmtornado.entity.TornadoEntity;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@EventBusSubscriber(modid = PMWeatherTornadoAddon.MOD_ID, bus = EventBusSubscriber.Bus.GAME, value = Dist.CLIENT)
public final class ClientSoundEvents {
    private static final Map<Integer, TornadoWindSound> PLAYING = new ConcurrentHashMap<>();

    private ClientSoundEvents() { }

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (!(event.getEntity() instanceof TornadoEntity tornado) || !event.getLevel().isClientSide()) return;
        TornadoWindSound sound = new TornadoWindSound(tornado);
        if (PLAYING.putIfAbsent(tornado.getId(), sound) == null) {
            Minecraft.getInstance().getSoundManager().play(sound);
        }
    }

    static void soundStopped(int entityId) {
        PLAYING.remove(entityId);
    }
}
