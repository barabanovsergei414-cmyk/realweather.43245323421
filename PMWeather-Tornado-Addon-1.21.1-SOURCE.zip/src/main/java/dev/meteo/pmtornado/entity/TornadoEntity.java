package dev.meteo.pmtornado.entity;

import dev.meteo.pmtornado.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.NetworkHooks;

import java.util.List;

/** A server-authoritative tornado funnel with a gradual growth/dissipation curve. */
public final class TornadoEntity extends Entity {
    private static final EntityDataAccessor<Float> DATA_STRENGTH =
            SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> DATA_LIFETIME =
            SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_RADIUS =
            SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_HEIGHT =
            SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> DATA_DISSIPATING =
            SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_DISSIPATE_TICKS =
            SynchedEntityData.defineId(TornadoEntity.class, EntityDataSerializers.INT);

    private int dissipateTicks = 0;
    private static final int SPAWN_RAMP_TICKS = 240; // 12 seconds
    private static final int DEFAULT_LIFETIME = 3600; // 3 minutes
    private static final int DISSIPATE_TICKS = 180; // 9 seconds

    public TornadoEntity(EntityType<? extends TornadoEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public TornadoEntity(Level level, double x, double y, double z, float strength, float radius, float height, int lifetime) {
        this(ModEntities.TORNADO.get(), level);
        this.setPos(x, y, z);
        configure(strength, radius, height, lifetime);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_STRENGTH, 0.85F);
        builder.define(DATA_LIFETIME, DEFAULT_LIFETIME);
        builder.define(DATA_RADIUS, 10.0F);
        builder.define(DATA_HEIGHT, 34.0F);
        builder.define(DATA_DISSIPATING, false);
        builder.define(DATA_DISSIPATE_TICKS, 0);
    }

    public void configure(float strength, float radius, float height, int lifetime) {
        entityData.set(DATA_STRENGTH, Mth.clamp(strength, 0.1F, 1.0F));
        entityData.set(DATA_RADIUS, Mth.clamp(radius, 4.0F, 24.0F));
        entityData.set(DATA_HEIGHT, Mth.clamp(height, 14.0F, 72.0F));
        entityData.set(DATA_LIFETIME, Mth.clamp(lifetime, 400, 12000));
    }

    public float getStrength() { return entityData.get(DATA_STRENGTH); }
    public float getBaseRadius() { return entityData.get(DATA_RADIUS); }
    public float getMaxHeight() { return entityData.get(DATA_HEIGHT); }
    public int getLifetime() { return entityData.get(DATA_LIFETIME); }
    public boolean isDissipating() { return entityData.get(DATA_DISSIPATING); }

    public void beginDissipating() {
        if (!level().isClientSide) {
            entityData.set(DATA_DISSIPATING, true);
            dissipateTicks = DISSIPATE_TICKS;
            entityData.set(DATA_DISSIPATE_TICKS, DISSIPATE_TICKS);
        }
    }

    public float getGrowthProgress(float partialTick) {
        float age = tickCount + partialTick;
        float in = smoothstep(age / SPAWN_RAMP_TICKS);
        float out = 1.0F;
        if (isDissipating()) {
            float remaining = Math.max(0.0F, (entityData.get(DATA_DISSIPATE_TICKS) - partialTick) / DISSIPATE_TICKS);
            out = smoothstep(remaining);
        } else {
            int fadeStart = getLifetime() - 240;
            if (tickCount > fadeStart) {
                out = smoothstep((getLifetime() - age) / 240.0F);
            }
        }
        return in * out;
    }

    private static float smoothstep(float value) {
        float t = Mth.clamp(value, 0.0F, 1.0F);
        return t * t * (3.0F - 2.0F * t);
    }

    @Override
    public void tick() {
        super.tick();
        if (isRemoved()) return;

        if (!level().isClientSide && level() instanceof ServerLevel serverLevel) {
            if (isDissipating()) {
                dissipateTicks--;
                entityData.set(DATA_DISSIPATE_TICKS, Math.max(0, dissipateTicks));
                if (dissipateTicks <= 0) {
                    discard();
                    return;
                }
            } else if (tickCount >= getLifetime()) {
                beginDissipating();
            }

            float growth = getGrowthProgress(0.0F);
            if (tickCount % 2 == 0 && growth > 0.01F) spawnDust(serverLevel, growth);
            if (tickCount % 2 == 0 && growth > 0.2F) applySuction(serverLevel, growth);
        }
    }

    private void spawnDust(ServerLevel level, float growth) {
        double r = getBaseRadius() * (0.25 + 0.75 * growth);
        for (int i = 0; i < 5; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double ring = r * (0.25 + random.nextDouble() * 0.75);
            double x = getX() + Math.cos(angle) * ring;
            double z = getZ() + Math.sin(angle) * ring;
            double y = getY() + 0.15 + random.nextDouble() * 1.3;
            BlockParticleOption dust = new BlockParticleOption(ParticleTypes.BLOCK,
                    random.nextBoolean() ? Blocks.COARSE_DIRT.defaultBlockState() : Blocks.SAND.defaultBlockState());
            level.sendParticles(dust, x, y, z, 1, 0.12, 0.18, 0.12, 0.04 + growth * 0.08);
        }
        if (tickCount % 6 == 0) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double ring = r * (0.2 + random.nextDouble() * 0.8);
            level.sendParticles(ParticleTypes.CLOUD,
                    getX() + Math.cos(angle) * ring, getY() + 1.0 + random.nextDouble() * 2.5,
                    getZ() + Math.sin(angle) * ring, 1, 0.25, 0.35, 0.25, 0.08);
        }
    }

    /** Applies a bounded inward/tangential/upward flow to nearby loose entities. */
    private void applySuction(ServerLevel level, float growth) {
        double radius = getBaseRadius() * 1.65;
        double height = getMaxHeight() * growth;
        AABB area = new AABB(getX() - radius, getY() - 1, getZ() - radius,
                getX() + radius, getY() + height, getZ() + radius);
        List<Entity> nearby = level.getEntities(this, area,
                entity -> entity.isAlive() && !(entity instanceof TornadoEntity));

        for (Entity entity : nearby) {
            if (entity instanceof Player player && (player.isCreative() || player.isSpectator())) continue;
            Vec3 offset = entity.position().subtract(position());
            double distance = Math.sqrt(offset.x * offset.x + offset.z * offset.z);
            if (distance < 0.75 || distance > radius) continue;
            double vertical = Mth.clamp(offset.y / Math.max(1.0, height), 0.0, 1.0);
            double falloff = (1.0 - distance / radius) * growth;
            double liftBand = 0.35 + 0.65 * (1.0 - vertical);
            double inward = 0.018 * getStrength() * falloff;
            double swirl = 0.045 * getStrength() * falloff;
            double lift = 0.012 * getStrength() * falloff * liftBand;

            double nx = offset.x / distance;
            double nz = offset.z / distance;
            Vec3 force = new Vec3(-nx * inward - nz * swirl, lift, -nz * inward + nx * swirl);
            Vec3 velocity = entity.getDeltaMovement().add(force);
            double horizontal = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
            if (horizontal > 1.05) {
                double scale = 1.05 / horizontal;
                velocity = new Vec3(velocity.x * scale, velocity.y, velocity.z * scale);
            }
            velocity = new Vec3(velocity.x, Mth.clamp(velocity.y, -0.45, 0.55), velocity.z);
            entity.setDeltaMovement(velocity);
            entity.hurtMarked = true;

            if (entity instanceof ItemEntity && tickCount % 12 == 0) {
                level.sendParticles(ParticleTypes.CLOUD, entity.getX(), entity.getY(), entity.getZ(),
                        1, 0.12, 0.12, 0.12, 0.03);
            }
        }
    }

    @Override
    public boolean isPickable() { return false; }

    @Override
    public boolean canBeCollidedWith() { return false; }

    @Override
    public boolean isPushable() { return false; }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putFloat("Strength", getStrength());
        tag.putFloat("Radius", getBaseRadius());
        tag.putFloat("Height", getMaxHeight());
        tag.putInt("Lifetime", getLifetime());
        tag.putBoolean("Dissipating", isDissipating());
        tag.putInt("DissipateTicks", dissipateTicks);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        configure(tag.getFloat("Strength"), tag.getFloat("Radius"), tag.getFloat("Height"), tag.getInt("Lifetime"));
        entityData.set(DATA_DISSIPATING, tag.getBoolean("Dissipating"));
        dissipateTicks = tag.getInt("DissipateTicks");
        entityData.set(DATA_DISSIPATE_TICKS, dissipateTicks);
    }

    public static TornadoEntity spawn(ServerLevel level, double x, double z, float strength) {
        int bx = Mth.floor(x);
        int bz = Mth.floor(z);
        int ground = level.getHeight(Heightmap.Types.WORLD_SURFACE, bx, bz);
        TornadoEntity tornado = new TornadoEntity(level,
                bx + 0.5, ground, bz + 0.5,
                strength, 8.0F + strength * 8.0F, 28.0F + strength * 22.0F, DEFAULT_LIFETIME);
        level.addFreshEntity(tornado);
        return tornado;
    }
}
