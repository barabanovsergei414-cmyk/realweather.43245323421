package dev.meteo.pmtornado.command;

import com.mojang.brigadier.arguments.FloatArgumentType;
import dev.meteo.pmtornado.entity.TornadoEntity;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

public final class TornadoCommands {
    private TornadoCommands() { }

    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("pmtornado")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("spawn")
                        .executes(context -> spawn(context.getSource().getPlayerOrException(), 0.85F))
                        .then(Commands.argument("strength", FloatArgumentType.floatArg(0.1F, 1.0F))
                                .executes(context -> spawn(context.getSource().getPlayerOrException(),
                                        FloatArgumentType.getFloat(context, "strength")))))
                .then(Commands.literal("clear")
                        .executes(context -> clear(context.getSource().getPlayerOrException()))));
    }

    private static int spawn(ServerPlayer player, float strength) {
        ServerLevel level = player.serverLevel();
        Vec3 ahead = player.getLookAngle().normalize().scale(30.0);
        TornadoEntity.spawn(level, player.getX() + ahead.x, player.getZ() + ahead.z, strength);
        player.sendSystemMessage(Component.literal("[PM Tornado] Tornado spawned. Strength: " + String.format("%.2f", strength)));
        return 1;
    }

    private static int clear(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        int removed = 0;
        for (TornadoEntity tornado : level.getEntitiesOfClass(TornadoEntity.class, player.getBoundingBox().inflate(256.0))) {
            tornado.beginDissipating();
            removed++;
        }
        player.sendSystemMessage(Component.literal("[PM Tornado] Dissipating " + removed + " nearby tornado(s)."));
        return removed;
    }
}
